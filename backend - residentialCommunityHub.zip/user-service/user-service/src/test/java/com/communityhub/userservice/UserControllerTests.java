package com.communityhub.userservice;

import com.communityhub.userservice.controller.UserController;
import com.communityhub.userservice.exception.*;
import com.communityhub.userservice.model.User;
import com.communityhub.userservice.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class UserControllerTests {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSignIn_UserNotFoundException() {
        String username = "testUser";
        String password = "testPassword";
        when(userService.signIn(username, password)).thenThrow(new UserNotFoundException("User not found"));
        String result = userController.signIn(username, password);
        assertEquals("User not found", result);
    }

    @Test
    void testSignIn_InvalidPasswordException() {
        String username = "testUser";
        String password = "testPassword";
        when(userService.signIn(username, password)).thenThrow(new InvalidPasswordException("Invalid password"));
        String result = userController.signIn(username, password);
        assertEquals("Invalid password", result);
    }

    @Test
    void testSignIn_InvalidUsernameException() {
        String username = "testUser";
        String password = "testPassword";
        when(userService.signIn(username, password)).thenThrow(new InvalidUsernameException("Invalid username"));
        String result = userController.signIn(username, password);
        assertEquals("Invalid username", result);
    }

    @Test
    void testSignIn_GeneralException() {
        String username = "testUser";
        String password = "testPassword";
        when(userService.signIn(username, password)).thenThrow(new RuntimeException("Some internal error"));
        String result = userController.signIn(username, password);
        assertEquals("An error occurred during sign-in process", result);
    }

    @Test
    void testSignIn_Success() {
        String username = "testUser";
        String password = "testPassword";
        when(userService.signIn(username, password)).thenReturn("User signed in successfully");
        String result = userController.signIn(username, password);
        assertEquals("User signed in successfully", result);
    }

    @Test
    void testSignUp_UserAlreadyExistException() {
        User user = new User();
        when(userService.signUp(user)).thenThrow(new UserAlreadyExistException("User already exists"));
        String result = userController.signUp(user);
        assertEquals("User already exists", result);
    }

    @Test
    void testSignUp_InvalidPasswordException() {
        User user = new User();
        when(userService.signUp(user)).thenThrow(new InvalidPasswordException("Invalid password"));
        String result = userController.signUp(user);
        assertEquals("Invalid password", result);
    }

    @Test
    void testSignUp_InvalidUsernameException() {
        User user = new User();
        when(userService.signUp(user)).thenThrow(new InvalidUsernameException("Invalid username"));
        String result = userController.signUp(user);
        assertEquals("Invalid username", result);
    }

    @Test
    void testSignUp_GeneralException() {
        User user = new User();
        when(userService.signUp(user)).thenThrow(new RuntimeException("Some internal error"));
        String result = userController.signUp(user);
        assertEquals("An error occurred during sign-up process", result);
    }

    @Test
    void testSignUp_Success() {
        User user = new User();
        when(userService.signUp(user)).thenReturn("User signed up successfully");
        String result = userController.signUp(user);
        assertEquals("User signed up successfully", result);
    }

    @Test
    void testGetAllUsers_Success() {
        List<User> users = new ArrayList<>();
        users.add(new User());
        users.add(new User());
        when(userService.getAllUsers()).thenReturn(users);
        List<User> result = userController.getAllUsers();
        assertEquals(users.size(), result.size());
    }

    @Test
    void testGetAllUsers_Exception() {
        when(userService.getAllUsers()).thenThrow(new RuntimeException("Some internal error"));
        List<User> result = userController.getAllUsers();
        assertEquals(null, result);
    }

    @Test
    void testGetUserFullName_UserNotFoundException() {
        Long userId = 123L;
        when(userService.getUserFullName(userId)).thenThrow(new UserNotFoundException("User not found"));
        String result = userController.getUserFullName(userId);
        assertEquals("User not found", result);
    }

    @Test
    void testGetUserFullName_GeneralException() {
        Long userId = 123L;
        when(userService.getUserFullName(userId)).thenThrow(new RuntimeException("Some internal error"));
        String result = userController.getUserFullName(userId);
        assertEquals("An error occurred while fetching user full name", result);
    }

    @Test
    void testGetUserFullName_Success() {
        Long userId = 123L;
        String fullName = "John Doe";
        when(userService.getUserFullName(userId)).thenReturn(fullName);
        String result = userController.getUserFullName(userId);
        assertEquals(fullName, result);
    }
}
