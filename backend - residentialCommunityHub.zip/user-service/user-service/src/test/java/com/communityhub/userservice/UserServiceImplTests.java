package com.communityhub.userservice;

import com.communityhub.userservice.exception.*;
import com.communityhub.userservice.model.User;
import com.communityhub.userservice.repository.UserRepository;
import com.communityhub.userservice.service.UserServiceImpl;

import org.junit.jupiter.api.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceImplTests {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserServiceImpl userService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testSignIn_Successful() {
        String username = "testUser";
        String password = "testPassword";
        User user = new User();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(password));
        when(userRepository.findByUsername(username)).thenReturn(user);
        when(passwordEncoder.matches(password, user.getPassword())).thenReturn(true);

        String result = userService.signIn(username, password);

        assertEquals("SUCCESSFULLY SIGNED IN", result);
    }

    @Test
    void testSignIn_UsernameNotFound() {
        String username = "nonexistentUser";
        String password = "testPassword";
        when(userRepository.findByUsername(username)).thenReturn(null);

        assertThrows(UserNotFoundException.class, () -> userService.signIn(username, password));
    }

    @Test
    void testSignIn_InvalidPassword() {
        String username = "testUser";
        String password = "incorrectPassword";
        User user = new User();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode("correctPassword"));
        when(userRepository.findByUsername(username)).thenReturn(user);
        when(passwordEncoder.matches(password, user.getPassword())).thenReturn(false);

        assertThrows(InvalidPasswordException.class, () -> userService.signIn(username, password));
    }

    @Test
    void testSignUp_Successful() {
        User user = new User();
        user.setUsername("newUser");
        user.setPassword("password");
        when(userRepository.findByUsername(user.getUsername())).thenReturn(null);
        when(passwordEncoder.encode(user.getPassword())).thenReturn("encodedPassword");

        String result = userService.signUp(user);

        assertEquals("Successfully Signed Up", result);
        assertEquals("encodedPassword", user.getPassword());
        verify(userRepository, times(1)).save(user);
    }

    @Test
    void testSignUp_UsernameAlreadyExists() {
        User user = new User();
        user.setUsername("existingUser");
        when(userRepository.findByUsername(user.getUsername())).thenReturn(new User());

        assertThrows(UserAlreadyExistException.class, () -> userService.signUp(user));
        verify(userRepository, never()).save(any());
    }


    @Test
    void testSignUp_InvalidUsername() {
        User user = new User();
        user.setUsername("");
        assertThrows(InvalidUsernameException.class, () -> userService.signUp(user));
        verify(userRepository, never()).save(any());
    }

    @Test
    void testSignUp_InvalidPassword() {
        User user = new User();
        user.setUsername("newUser");
        user.setPassword("");
        assertThrows(InvalidPasswordException.class, () -> userService.signUp(user));
        verify(userRepository, never()).save(any());
    }

    @Test
    void testGetAllUsers() {
        List<User> userList = new ArrayList<>();
        when(userRepository.findAll()).thenReturn(userList);

        List<User> result = userService.getAllUsers();

        assertSame(userList, result);
    }

    @Test
    void testGetUserFullName_UserFound() {
        Long userId = 1L;
        User user = new User();
        user.setUserId(userId);
        user.setFirstName("John");
        user.setLastName("Doe");
        when(userRepository.findById(userId)).thenReturn(java.util.Optional.of(user));

        String fullName = userService.getUserFullName(userId);

        assertEquals("John Doe", fullName);
    }

    @Test
    void testGetUserFullName_UserNotFound() {
        Long userId = 1L;
        when(userRepository.findById(userId)).thenReturn(java.util.Optional.empty());

        assertThrows(UserNotFoundException.class, () -> userService.getUserFullName(userId));
    }

    @Test
    void testGetAllUsers_ExceptionThrown() {
        when(userRepository.findAll()).thenThrow(new RuntimeException("Test Exception"));

        assertThrows(RuntimeException.class, () -> userService.getAllUsers());
    }

    @Test
    void testSignUp_UserRepositorySaveException() {
        User user = new User();
        user.setUsername("newUser");
        user.setPassword("password");
        when(userRepository.findByUsername(user.getUsername())).thenReturn(null);
        when(passwordEncoder.encode(user.getPassword())).thenReturn("encodedPassword");
        doThrow(new RuntimeException("Test Exception")).when(userRepository).save(any());

        assertThrows(RuntimeException.class, () -> userService.signUp(user));
    }
}
