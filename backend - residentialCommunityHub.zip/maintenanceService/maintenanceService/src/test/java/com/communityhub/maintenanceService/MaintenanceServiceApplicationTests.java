package com.communityhub.maintenanceService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaintenanceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
