import Carousel from "../../Carousel/Carousel";
import AdminNavbar from "../AdminNavbar/AdminNavbar";
import './AdminHomepage.css';
import image01 from '../../Media/Images/admin-homepage.jpg';

function AdminHomepage() {
    return (
        <div>
            <AdminNavbar />
            <div className="admin-homepage-container">
                
            </div>
        </div>
    );
}

export default AdminHomepage;