
function NoPageFound() {
    return (
        <div>
            <div>
                <h1>No Page Found</h1>
            </div>
        </div>
    );
}

export default NoPageFound;