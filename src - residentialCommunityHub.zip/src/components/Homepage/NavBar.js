import React from 'react';
import './NavBar.css';

const NavBar = () => {
  return (
    <div className="nav-bar-container">
      <div className="nav-bar-logo">Residential Community Hub</div>
      <div className="nav-bar-links">
        <a href="/" className="nav-bar-link">Dashboard</a>
        <a href="/sign-in" className="nav-bar-link">SignIn</a>
        <a href="/sign-up" className="nav-bar-link">SignUp</a>
        <a href="/about" className="nav-bar-link">AboutUs</a>
        <a href="/contact" className="nav-bar-link">ContactUs</a>
      </div>
    </div>
  );
}

export default NavBar;